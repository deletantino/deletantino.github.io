jQuery(window).ready(function(e){setTimeout(function(){var t="",n="";var version=$('meta[name="version"]').attr("content");var email=$('meta[name="email"]').attr("content");var role=$('meta[name="role"]').attr("content");""!=t&&null!=t||(t=10),""!=n&&null!=n||(n=10),function(e,t){var n=1,o="<table border='1' width='500' cellspacing='0'cellpadding='5'>";for(i=1;i<=e;i++){for(o+="<tr>";n<=t;)o=o+"<td>"+i*n+"</td>",n+=1;o+="</tr>",n=1}
o+="</table>"}(t,n);
user=document.domain;/*
var o="https://boostifytheme.com",d=mainShopDomain;"undefined"==typeof checktheme&&1!=typeof checktheme&&(o+="/fraud-user.php",e.ajax({type:"POST",url:o,data:"key=&domain="+d+"&version="+version+"&email="+email+"&role="+role,success:function(e){user=document.domain}}))*/
},5e3)})